cd ./neofetch-7.1.0
make install